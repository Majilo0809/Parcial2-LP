grammar CRUD;

programa: sentencia+ EOF;

// CRUD
sentencia
    : crear
    | leer
    | actualizar
    | eliminar
    ;

crear: 'CREATE' ID objeto;
leer: 'READ' ID objeto;
actualizar: 'UPDATE' ID objeto objeto;
eliminar: 'DELETE' ID objeto;

objeto: '{' pares '}';

pares: par (',' par)*;

par: STRING ':' valor;

valor
    : STRING
    | NUMBER
    ;

// Tokens
ID: [a-zA-Z_][a-zA-Z0-9_]*;

STRING: '"' (~["\\] | '\\' .)* '"';

NUMBER: [0-9]+;

WS: [ \t\r\n]+ -> skip;
