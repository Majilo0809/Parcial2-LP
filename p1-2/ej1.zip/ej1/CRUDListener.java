// Generated from CRUD.g4 by ANTLR 4.13.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link CRUDParser}.
 */
public interface CRUDListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link CRUDParser#programa}.
	 * @param ctx the parse tree
	 */
	void enterPrograma(CRUDParser.ProgramaContext ctx);
	/**
	 * Exit a parse tree produced by {@link CRUDParser#programa}.
	 * @param ctx the parse tree
	 */
	void exitPrograma(CRUDParser.ProgramaContext ctx);
	/**
	 * Enter a parse tree produced by {@link CRUDParser#sentencia}.
	 * @param ctx the parse tree
	 */
	void enterSentencia(CRUDParser.SentenciaContext ctx);
	/**
	 * Exit a parse tree produced by {@link CRUDParser#sentencia}.
	 * @param ctx the parse tree
	 */
	void exitSentencia(CRUDParser.SentenciaContext ctx);
	/**
	 * Enter a parse tree produced by {@link CRUDParser#crear}.
	 * @param ctx the parse tree
	 */
	void enterCrear(CRUDParser.CrearContext ctx);
	/**
	 * Exit a parse tree produced by {@link CRUDParser#crear}.
	 * @param ctx the parse tree
	 */
	void exitCrear(CRUDParser.CrearContext ctx);
	/**
	 * Enter a parse tree produced by {@link CRUDParser#leer}.
	 * @param ctx the parse tree
	 */
	void enterLeer(CRUDParser.LeerContext ctx);
	/**
	 * Exit a parse tree produced by {@link CRUDParser#leer}.
	 * @param ctx the parse tree
	 */
	void exitLeer(CRUDParser.LeerContext ctx);
	/**
	 * Enter a parse tree produced by {@link CRUDParser#actualizar}.
	 * @param ctx the parse tree
	 */
	void enterActualizar(CRUDParser.ActualizarContext ctx);
	/**
	 * Exit a parse tree produced by {@link CRUDParser#actualizar}.
	 * @param ctx the parse tree
	 */
	void exitActualizar(CRUDParser.ActualizarContext ctx);
	/**
	 * Enter a parse tree produced by {@link CRUDParser#eliminar}.
	 * @param ctx the parse tree
	 */
	void enterEliminar(CRUDParser.EliminarContext ctx);
	/**
	 * Exit a parse tree produced by {@link CRUDParser#eliminar}.
	 * @param ctx the parse tree
	 */
	void exitEliminar(CRUDParser.EliminarContext ctx);
	/**
	 * Enter a parse tree produced by {@link CRUDParser#objeto}.
	 * @param ctx the parse tree
	 */
	void enterObjeto(CRUDParser.ObjetoContext ctx);
	/**
	 * Exit a parse tree produced by {@link CRUDParser#objeto}.
	 * @param ctx the parse tree
	 */
	void exitObjeto(CRUDParser.ObjetoContext ctx);
	/**
	 * Enter a parse tree produced by {@link CRUDParser#pares}.
	 * @param ctx the parse tree
	 */
	void enterPares(CRUDParser.ParesContext ctx);
	/**
	 * Exit a parse tree produced by {@link CRUDParser#pares}.
	 * @param ctx the parse tree
	 */
	void exitPares(CRUDParser.ParesContext ctx);
	/**
	 * Enter a parse tree produced by {@link CRUDParser#par}.
	 * @param ctx the parse tree
	 */
	void enterPar(CRUDParser.ParContext ctx);
	/**
	 * Exit a parse tree produced by {@link CRUDParser#par}.
	 * @param ctx the parse tree
	 */
	void exitPar(CRUDParser.ParContext ctx);
	/**
	 * Enter a parse tree produced by {@link CRUDParser#valor}.
	 * @param ctx the parse tree
	 */
	void enterValor(CRUDParser.ValorContext ctx);
	/**
	 * Exit a parse tree produced by {@link CRUDParser#valor}.
	 * @param ctx the parse tree
	 */
	void exitValor(CRUDParser.ValorContext ctx);
}