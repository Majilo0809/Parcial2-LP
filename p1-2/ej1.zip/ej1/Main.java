import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

public class Main {
    public static void main(String[] args) throws Exception {

        CharStream input = CharStreams.fromFileName("test.txt");
        CRUDLexer lexer = new CRUDLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        CRUDParser parser = new CRUDParser(tokens);

        parser.removeErrorListeners();
        parser.setErrorHandler(new BailErrorStrategy());

        try {
            CRUDParser.ProgramaContext tree = parser.programa();

            for (CRUDParser.SentenciaContext s : tree.sentencia()) {

                if (s.crear() != null) {
                    System.out.println("Registro creado en: " + s.crear().ID().getText());
                }

                else if (s.leer() != null) {
                    System.out.println("Consulta realizada en: " + s.leer().ID().getText());
                }

                else if (s.actualizar() != null) {
                    System.out.println("Registro actualizado en: " + s.actualizar().ID().getText());
                }

                else if (s.eliminar() != null) {
                    System.out.println("Registro eliminado en: " + s.eliminar().ID().getText());
                }
            }

        } catch (Exception e) {
            System.out.println("Error de sintaxis en la entrada");
        }
    }
}
