grammar gramatica;

prog: prop+ EOF;

prop
    : 'if' 'E' 'then' prop
    | prop_emparejada
    ;

prop_emparejada
    : 'if' 'E' 'then' prop_emparejada 'else' prop
    | 'S'
    ;

WS: [ \t\r\n]+ -> skip;
