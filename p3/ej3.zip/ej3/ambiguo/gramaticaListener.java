// Generated from gramatica.g4 by ANTLR 4.13.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link gramaticaParser}.
 */
public interface gramaticaListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#prog}.
	 * @param ctx the parse tree
	 */
	void enterProg(gramaticaParser.ProgContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#prog}.
	 * @param ctx the parse tree
	 */
	void exitProg(gramaticaParser.ProgContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#prop}.
	 * @param ctx the parse tree
	 */
	void enterProp(gramaticaParser.PropContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#prop}.
	 * @param ctx the parse tree
	 */
	void exitProp(gramaticaParser.PropContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#prop_emparejada}.
	 * @param ctx the parse tree
	 */
	void enterProp_emparejada(gramaticaParser.Prop_emparejadaContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#prop_emparejada}.
	 * @param ctx the parse tree
	 */
	void exitProp_emparejada(gramaticaParser.Prop_emparejadaContext ctx);
}