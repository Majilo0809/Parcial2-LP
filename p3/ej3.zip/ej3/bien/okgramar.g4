grammar okgramar;

prog: stmt+ EOF;

stmt
    : matched
    | unmatched
    ;

matched
    : 'if' 'E' 'then' matched 'else' matched
    | 'S'
    ;

unmatched
    : 'if' 'E' 'then' stmt
    | 'if' 'E' 'then' matched 'else' unmatched
    ;

WS: [ \t\r\n]+ -> skip;
