// Generated from okgramar.g4 by ANTLR 4.13.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link okgramarParser}.
 */
public interface okgramarListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link okgramarParser#prog}.
	 * @param ctx the parse tree
	 */
	void enterProg(okgramarParser.ProgContext ctx);
	/**
	 * Exit a parse tree produced by {@link okgramarParser#prog}.
	 * @param ctx the parse tree
	 */
	void exitProg(okgramarParser.ProgContext ctx);
	/**
	 * Enter a parse tree produced by {@link okgramarParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterStmt(okgramarParser.StmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link okgramarParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitStmt(okgramarParser.StmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link okgramarParser#matched}.
	 * @param ctx the parse tree
	 */
	void enterMatched(okgramarParser.MatchedContext ctx);
	/**
	 * Exit a parse tree produced by {@link okgramarParser#matched}.
	 * @param ctx the parse tree
	 */
	void exitMatched(okgramarParser.MatchedContext ctx);
	/**
	 * Enter a parse tree produced by {@link okgramarParser#unmatched}.
	 * @param ctx the parse tree
	 */
	void enterUnmatched(okgramarParser.UnmatchedContext ctx);
	/**
	 * Exit a parse tree produced by {@link okgramarParser#unmatched}.
	 * @param ctx the parse tree
	 */
	void exitUnmatched(okgramarParser.UnmatchedContext ctx);
}