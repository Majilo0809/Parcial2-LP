import time

grammar = {
    "E": [("E", "X"), ("T",)],
    "X": [("PLUS", "T")],
    "T": [("T", "Y"), ("F",)],
    "Y": [("MULT", "F")],
    "F": [("NUM",)],
    "PLUS": [("+",)],
    "MULT": [("*",)],
    "NUM": [("num",)]
}

def closure(cell):
    added = True
    while added:
        added = False
        for var, rules in grammar.items():
            for rule in rules:
                if len(rule) == 1 and rule[0] in cell and var not in cell:
                    cell.add(var)
                    added = True

def cyk_parser(tokens):
    n = len(tokens)
    table = [[set() for _ in range(n)] for _ in range(n)]

    for i in range(n):
        for var, rules in grammar.items():
            for rule in rules:
                if len(rule) == 1 and rule[0] == tokens[i]:
                    table[i][i].add(var)
        closure(table[i][i])

    for l in range(2, n + 1):
        for i in range(n - l + 1):
            j = i + l - 1
            for k in range(i, j):
                for var, rules in grammar.items():
                    for rule in rules:
                        if len(rule) == 2:
                            B, C = rule
                            if B in table[i][k] and C in table[k + 1][j]:
                                table[i][j].add(var)
            closure(table[i][j])

    return "E" in table[0][n - 1]

tests = [
    ["num","+","num"],
    ["num","+","num","*","num"],
    ["num","*","num","+","num"],
    ["num","+","*","num"]
]

for t in tests:
    start = time.time()
    result = cyk_parser(t)
    end = time.time()
    print("Entrada:", t)
    print("CYK válido:", result)
    print("Tiempo:", end - start)
    print("------")
