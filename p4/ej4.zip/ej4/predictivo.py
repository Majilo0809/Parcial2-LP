import time

def match(t):
    global pos, tokens
    if pos < len(tokens) and tokens[pos] == t:
        pos += 1
        return True
    return False

def F():
    global pos
    if match("num"):
        return True
    return False

def T():
    global pos
    if not F():
        return False
    while pos < len(tokens) and tokens[pos] == "*":
        match("*")
        if not F():
            return False
    return True

def E():
    global pos
    if not T():
        return False
    while pos < len(tokens) and tokens[pos] == "+":
        match("+")
        if not T():
            return False
    return True


tests = [
    ["num","+","num"],
    ["num","+","num","*","num"],
    ["num","*","num","+","num"],
    ["num","+","*","num"]
]

for t in tests:
    tokens = t
    pos = 0

    start = time.time()
    result = E() and pos == len(tokens)
    end = time.time()

    print("Entrada:", t)
    print("Predictivo válido:", result)
    print("Tiempo:", end - start)
    print("------")
