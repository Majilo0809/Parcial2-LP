tokens = []
pos = 0

def match(t):
    global pos
    if pos < len(tokens) and tokens[pos] == t:
        pos += 1
        return True
    return False

def S():
    global pos

    start = pos

    if pos < len(tokens) and tokens[pos] == "id":
        pos += 1
        if match("="):
            if E():
                return True
        pos = start

    if match("if"):
        if C() and match("then") and S() and match("else") and S():
            return True

    return False

def C():
    if E():
        if match(">") or match("<") or match("=="):
            if E():
                return True
    return False

def E():
    if match("id"):
        return True
    if match("num"):
        return True
    return False


tests = [
    ["id","=","num"],
    ["if","id",">","num","then","id","=","num","else","id","=","num"],
    ["if","id","==","id","then","id","=","num","else","id","=","num"],
    ["if","num","<","num","then","id","=","num","else","id","=","num"],
    ["if","id","then","id","=","num"],
    ["id","="]
]

for t in tests:
    tokens = t
    pos = 0

    result = S() and pos == len(tokens)

    print("Entrada:", t)
    print("Válido:", result)
    print("------")
